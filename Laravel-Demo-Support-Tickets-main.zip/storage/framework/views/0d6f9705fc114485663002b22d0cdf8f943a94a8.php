<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Tickets')); ?>

     <?php $__env->endSlot(); ?>

    <div class="mb-4 flex justify-between">
        <a class="rounded-lg border border-transparent bg-purple-600 px-4 py-2 text-center text-sm font-medium leading-5 text-white transition-colors duration-150 hover:bg-purple-700 focus:outline-none focus:ring active:bg-purple-600"
            href="<?php echo e(route('tickets.create')); ?>">
            <?php echo e(__('Create')); ?>

        </a>
        <div class="flex space-x-2">
            <select
                class="block w-full rounded-md border-gray-300 shadow-sm focus-within:text-primary-600 focus:border-primary-300 focus:ring-primary-200 focus:ring focus:ring-opacity-50 font-sans"
                name="status" id="status" onChange="window.location.href=this.value">
                <option value="<?php echo e(clearQueryString('status')); ?>">-- Select Status --</option>
                <?php $__currentLoopData = \Coderflex\LaravelTicket\Enums\Status::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e(toggle('status', $status->value)); ?>" <?php if($status->value == request('status')): echo 'selected'; endif; ?>><?php echo e($status->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <select
                class="block w-full rounded-md border-gray-300 shadow-sm focus-within:text-primary-600 focus:border-primary-300 focus:ring-primary-200 focus:ring focus:ring-opacity-50 font-sans"
                name="priority" id="priority" onchange="window.location.href=this.value">
                <option value="<?php echo e(clearQueryString('priority')); ?>">-- Select Priority --</option>
                <?php $__currentLoopData = \Coderflex\LaravelTicket\Enums\Priority::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e(toggle('priority', $priority->value)); ?>" <?php if($priority->value ==
                    request('priority')): echo 'selected'; endif; ?>><?php echo e($priority->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <select
                class="block w-full rounded-md border-gray-300 shadow-sm focus-within:text-primary-600 focus:border-primary-300 focus:ring-primary-200 focus:ring focus:ring-opacity-50 font-sans"
                name="category" id="category" onchange="window.location.href=this.value">
                <option value="<?php echo e(clearQueryString('category')); ?>">-- Select Category --</option>
                <?php $__currentLoopData = \App\Models\Category::pluck('name', 'id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e(toggle('category', (string) $id)); ?>" <?php if($id==request('category')): echo 'selected'; endif; ?>><?php echo e($name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>



    </div>

    <div class="rounded-lg bg-white p-4 shadow-xs">

        <div class="mb-8 w-full overflow-hidden rounded-lg border shadow-xs">
            <div class="w-full overflow-x-auto">
                <table class="w-full whitespace-no-wrap">
                    <thead>
                        <tr
                            class="border-b bg-gray-50 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">
                            <th class="px-4 py-3">Date</th>
                            <th class="px-4 py-3">Title</th>
                            <th class="px-4 py-3">Author</th>
                            <th class="px-4 py-3">Status</th>
                            <th class="px-4 py-3">Priority</th>
                            <th class="px-4 py-3">Categories</th>
                            <th class="px-4 py-3">Labels</th>
                            
                            <th></th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y">
                        <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="text-gray-700">
                            <td class="px-4 py-3 text-sm">
                                <?php echo e($ticket->created_at); ?>

                            </td>
                            <td class="px-4 py-3 text-sm">
                                <a href="<?php echo e(route('tickets.show', $ticket)); ?>" class="hover:underline"><?php echo e($ticket->title); ?></a>
                            </td>
                            <td class="px-4 py-3 text-sm">
                                <?php echo e($ticket->user->name); ?>

                            </td>
                            <td class="px-4 py-3 text-sm">
                                <?php if( $ticket->status == "open"): ?>
                                <span class="rounded-full bg-red-50 px-2 py-2"><?php echo e($ticket->status); ?></span>
                                <?php elseif($ticket->status =='closed'): ?>
                                <span class="rounded-full bg-blue-50  px-2 py-2"><?php echo e($ticket->status); ?></span>
                                <?php elseif($ticket->status =='archived'): ?>
                                <span class="rounded-full bg-green-50  px-2 py-2"><?php echo e($ticket->status); ?></span>
                                <?php endif; ?>

                            </td>
                            <td class="px-4 py-3 text-sm">
                                <?php echo e($ticket->priority); ?>

                            </td>
                            <td class="px-4 py-3 text-sm">
                                <?php $__currentLoopData = $ticket->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="rounded-full bg-gray-50 px-2 py-2"><?php echo e($category->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td class="px-4 py-3 text-sm">
                                <?php $__currentLoopData = $ticket->labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="rounded-full bg-gray-50 px-2 py-2"><?php echo e($label->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            
                            <td class="px-4 py-3 space-x-2">
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'admin|agent')): ?>
                                <a class="rounded-lg border-2 border-transparent bg-purple-600 px-4 py-2 text-center text-sm font-medium leading-5 text-white transition-colors duration-150 hover:bg-purple-700 focus:outline-none focus:ring active:bg-purple-600"
                                    href="<?php echo e(route('tickets.edit', $ticket)); ?>">
                                    <?php echo e(__('Edit')); ?>

                                </a>
                                <?php endif; ?>

                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                                <form action="<?php echo e(route('tickets.destroy', $ticket)); ?>" method="POST"
                                    onsubmit="return confirm('Are you sure?')" style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                        Delete
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="px-4 py-3" colspan="4">No tickets found.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($tickets->hasPages()): ?>
            <div
                class="border-t bg-gray-50 px-4 py-3 text-xs font-semibold uppercase tracking-wide text-gray-500 sm:grid-cols-9">
                <?php echo e($tickets->withQueryString()->links()); ?>

            </div>
            <?php endif; ?>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\ahmed\Desktop\erp\Laravel-Demo-Support-Tickets-main\resources\views/tickets/index.blade.php ENDPATH**/ ?>