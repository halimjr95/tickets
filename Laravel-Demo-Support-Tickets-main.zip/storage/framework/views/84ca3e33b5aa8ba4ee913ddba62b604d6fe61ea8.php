<!DOCTYPE html>
<html x-data="data" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo e(asset('images/170.png')); ?>" type="image/x-icon">

    
    <title>SupportFlow by HMC</title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/init-alpine.js')); ?>"></script>
</head>

<body>
    <div class="flex h-screen bg-gray-50" :class="{ 'overflow-hidden': isSideMenuOpen }">
        <!-- Desktop sidebar -->
        <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Mobile sidebar -->
        <!-- Backdrop -->
        <?php echo $__env->make('layouts.navigation-mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="flex flex-col flex-1 w-full">
            <?php echo $__env->make('layouts.top-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <main class="h-full overflow-y-auto">
                <div class="container px-6 mx-auto grid">
                    <?php if(isset($header)): ?>
                    <h2 class="my-6 text-2xl font-semibold text-gray-700">
                        <?php echo e($header); ?>

                    </h2>
                    <?php endif; ?>

                    <?php echo e($slot); ?>

                </div>
            </main>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const inputElement = document.querySelector('input[type="file"]');

            const pond = FilePond.create(inputElement, {
                server: {
                    url: '<?php echo e(route('tickets.upload')); ?>',
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    }
                }
            });
        });
    </script>
</body>

</html><?php /**PATH C:\Users\ahmed\Desktop\erp\Laravel-Demo-Support-Tickets-main\resources\views/layouts/app.blade.php ENDPATH**/ ?>