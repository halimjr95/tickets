<li>
    <a <?php echo e($attributes->merge(['class' => 'inline-flex items-center w-full px-2 py-1 text-sm font-semibold transition-colors duration-150 rounded-md hover:bg-gray-100 hover:text-gray-800'])); ?>>
        <?php echo e($icon ?? ''); ?>

        <span><?php echo e($slot); ?></span>
    </a>
</li>
<?php /**PATH C:\Users\ahmed\Desktop\erp\Laravel-Demo-Support-Tickets-main\resources\views/components/dropdown-link.blade.php ENDPATH**/ ?>