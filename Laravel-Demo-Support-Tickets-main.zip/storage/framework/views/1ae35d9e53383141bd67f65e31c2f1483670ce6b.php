<!DOCTYPE html>
<html x-data="data" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo e(asset('images/170.png')); ?>" type="image/x-icon">

    
    <title>SupportFlow by HMC</title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/init-alpine.js')); ?>"></script>
</head>

<body>

    <div class="flex items-center min-h-screen p-6 bg-gray-50">
        <div class="flex-1 h-full max-w-4xl mx-auto overflow-hidden bg-white rounded-lg shadow-xl">
            <?php echo e($slot); ?>

        </div>
    </div>

</body>

</html><?php /**PATH C:\Users\ahmed\Desktop\erp\Laravel-Demo-Support-Tickets-main\resources\views/layouts/guest.blade.php ENDPATH**/ ?>